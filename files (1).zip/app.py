"""
=====================================================
  STOCK ANALYZER WEB APP — app.py  (Fixed v2.0)
=====================================================
  HOW TO RUN:
  1. pip install flask yfinance pandas
  2. Put app.py and index.html in the SAME folder
  3. python app.py
  4. Open browser: http://127.0.0.1:5000
"""

from flask import Flask, request, jsonify
import yfinance as yf
import pandas as pd

app = Flask(__name__)

# ── Serve the HTML page ──────────────────────────
@app.route("/")
def home():
    try:
        with open("index.html", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "<h2>Error: index.html not found! Make sure both files are in the same folder.</h2>", 404

# ── Helper: RSI ──────────────────────────────────
def calc_rsi(prices, period=14):
    delta    = prices.diff()
    gains    = delta.where(delta > 0, 0)
    losses   = -delta.where(delta < 0, 0)
    avg_gain = gains.rolling(window=period).mean()
    avg_loss = losses.rolling(window=period).mean()
    rs       = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

# ── Helper: MACD ─────────────────────────────────
def calc_macd(prices, fast=12, slow=26, signal=9):
    ema_fast    = prices.ewm(span=fast,   adjust=False).mean()
    ema_slow    = prices.ewm(span=slow,   adjust=False).mean()
    macd_line   = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram   = macd_line - signal_line
    return macd_line, signal_line, histogram

# ── Helper: Bollinger Bands ──────────────────────
def calc_bb(prices, period=20, num_std=2):
    middle = prices.rolling(window=period).mean()
    std    = prices.rolling(window=period).std()
    upper  = middle + (num_std * std)
    lower  = middle - (num_std * std)
    pct_b  = (prices - lower) / (upper - lower)
    bwidth = (upper - lower) / middle * 100
    return upper, middle, lower, pct_b, bwidth

# ── Helper: safe float ───────────────────────────
def sf(val, digits=2):
    try:
        v = float(val)
        if pd.isna(v): return None
        return round(v, digits)
    except:
        return None

# ── Main Analysis Endpoint ───────────────────────
@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        body   = request.get_json()
        symbol = body.get("symbol", "").upper().strip()
        period = body.get("period", "90")

        if not symbol:
            return jsonify({"error": "Please enter a stock symbol!"}), 400

        period_str = period + "d"

        # Download data
        data  = yf.download(symbol, period=period_str, progress=False)
        stock = yf.Ticker(symbol)

        if data.empty:
            return jsonify({"error": f"No data found for '{symbol}'. Check the symbol!"}), 404

        info         = stock.info
        company_name = info.get("longName", symbol)
        currency     = info.get("currency", "USD")

        # Flatten columns
        close  = data["Close"].squeeze()
        high   = data["High"].squeeze()
        low    = data["Low"].squeeze()
        volume = data["Volume"].squeeze()

        # Basic stats
        latest = float(close.iloc[-1])
        first  = float(close.iloc[0])
        change = latest - first
        pct    = (change / first) * 100

        daily_ret     = close.pct_change() * 100
        avg_daily     = float(daily_ret.mean())

        # SMA
        sma7  = sf(close.rolling(7).mean().iloc[-1])  if len(data) >= 7  else None
        sma20 = sf(close.rolling(20).mean().iloc[-1]) if len(data) >= 20 else None

        # RSI
        rsi_vals = rsi_signal = current_rsi = None
        if len(data) >= 14:
            rsi_series  = calc_rsi(close)
            current_rsi = sf(rsi_series.iloc[-1])
            rsi_vals    = [sf(v) for v in rsi_series.values]
            if current_rsi > 70:   rsi_signal = "OVERBOUGHT"
            elif current_rsi < 30: rsi_signal = "OVERSOLD"
            else:                  rsi_signal = "NORMAL"

        # MACD
        macd_vals = sig_vals = hist_vals = None
        macd_signal = "UNKNOWN"
        curr_macd = curr_sig = curr_hist = None
        if len(data) >= 26:
            ml, sl, hl       = calc_macd(close)
            curr_macd        = sf(ml.iloc[-1], 4)
            curr_sig         = sf(sl.iloc[-1], 4)
            curr_hist        = sf(hl.iloc[-1], 4)
            prev_macd        = float(ml.iloc[-2])
            prev_sig         = float(sl.iloc[-2])
            macd_vals        = [sf(v, 4) for v in ml.values]
            sig_vals         = [sf(v, 4) for v in sl.values]
            hist_vals        = [sf(v, 4) for v in hl.values]
            bull_cross = (prev_macd < prev_sig) and (float(ml.iloc[-1]) > float(sl.iloc[-1]))
            bear_cross = (prev_macd > prev_sig) and (float(ml.iloc[-1]) < float(sl.iloc[-1]))
            if bull_cross:                          macd_signal = "BULLISH_CROSSOVER"
            elif bear_cross:                        macd_signal = "BEARISH_CROSSOVER"
            elif float(ml.iloc[-1]) > float(sl.iloc[-1]): macd_signal = "BULLISH"
            else:                                   macd_signal = "BEARISH"

        # Bollinger Bands
        bb_u = bb_m = bb_l = bb_pct = bb_bw = None
        bb_upper_v = bb_lower_v = bb_bw_v = None
        bb_signal = "UNKNOWN"
        bb_squeeze = False
        curr_upper = curr_lower = curr_bw = avg_bw = None
        if len(data) >= 20:
            bbu, bbm, bbl, bbp, bbbw = calc_bb(close)
            curr_upper = sf(bbu.iloc[-1])
            curr_lower = sf(bbl.iloc[-1])
            curr_bw    = sf(bbbw.iloc[-1])
            avg_bw     = sf(float(bbbw.mean()))
            bb_upper_v = [sf(v) for v in bbu.values]
            bb_lower_v = [sf(v) for v in bbl.values]
            bb_bw_v    = [sf(v) for v in bbbw.values]
            if latest >= float(bbu.iloc[-1]):          bb_signal = "ABOVE_UPPER"
            elif latest <= float(bbl.iloc[-1]):        bb_signal = "BELOW_LOWER"
            elif latest > float(bbm.iloc[-1]):         bb_signal = "UPPER_ZONE"
            else:                                      bb_signal = "LOWER_ZONE"
            if float(bbbw.iloc[-1]) < float(bbbw.mean()) * 0.7:
                bb_squeeze = True

        # Volume analysis
        avg_vol    = float(volume.mean())
        latest_vol = float(volume.iloc[-1])
        vol_ratio  = latest_vol / avg_vol
        recent_vol = float(volume.iloc[-5:].mean()) if len(data) >= 5 else avg_vol
        unusual    = int((volume > avg_vol * 2).sum())

        if vol_ratio >= 3:     vol_signal = "EXTREMELY_HIGH"
        elif vol_ratio >= 2:   vol_signal = "HIGH"
        elif vol_ratio >= 1.5: vol_signal = "ABOVE_AVERAGE"
        elif vol_ratio < 0.5:  vol_signal = "LOW"
        else:                  vol_signal = "NORMAL"

        # Score calculation
        score = 0
        breakdown = []

        if sma20 and latest > sma20:
            score += 1; breakdown.append({"text": "Price ABOVE 20-day average", "val": "+1", "pos": True})
        else:
            score -= 1; breakdown.append({"text": "Price BELOW 20-day average", "val": "-1", "pos": False})

        if sma7 and sma20 and sma7 > sma20:
            score += 1; breakdown.append({"text": "Short-term trend is UP", "val": "+1", "pos": True})
        else:
            score -= 1; breakdown.append({"text": "Short-term trend is DOWN", "val": "-1", "pos": False})

        if pct > 0:
            score += 1; breakdown.append({"text": f"Stock gained {abs(pct):.1f}% this period", "val": "+1", "pos": True})
        else:
            score -= 1; breakdown.append({"text": f"Stock lost {abs(pct):.1f}% this period", "val": "-1", "pos": False})

        if rsi_signal == "OVERSOLD":
            score += 2; breakdown.append({"text": f"RSI OVERSOLD ({current_rsi:.1f}) - bounce likely!", "val": "+2", "pos": True})
        elif rsi_signal == "OVERBOUGHT":
            score -= 2; breakdown.append({"text": f"RSI OVERBOUGHT ({current_rsi:.1f}) - may drop", "val": "-2", "pos": False})
        elif rsi_signal:
            breakdown.append({"text": f"RSI NORMAL ({current_rsi:.1f})", "val": "0", "pos": None})

        if macd_signal == "BULLISH_CROSSOVER":
            score += 3; breakdown.append({"text": "MACD BULLISH CROSSOVER!", "val": "+3", "pos": True})
        elif macd_signal == "BEARISH_CROSSOVER":
            score -= 3; breakdown.append({"text": "MACD BEARISH CROSSOVER!", "val": "-3", "pos": False})
        elif macd_signal == "BULLISH":
            score += 1; breakdown.append({"text": "MACD Bullish momentum", "val": "+1", "pos": True})
        elif macd_signal == "BEARISH":
            score -= 1; breakdown.append({"text": "MACD Bearish momentum", "val": "-1", "pos": False})

        if bb_signal == "BELOW_LOWER":
            score += 2; breakdown.append({"text": "BB: Price at lower band - bounce likely!", "val": "+2", "pos": True})
        elif bb_signal == "ABOVE_UPPER":
            score -= 2; breakdown.append({"text": "BB: Price at upper band - pullback likely!", "val": "-2", "pos": False})
        elif bb_signal == "UPPER_ZONE":
            score += 1; breakdown.append({"text": "BB: Price in upper zone", "val": "+1", "pos": True})
        elif bb_signal == "LOWER_ZONE":
            score -= 1; breakdown.append({"text": "BB: Price in lower zone", "val": "-1", "pos": False})
        if bb_squeeze:
            breakdown.append({"text": "BB SQUEEZE - Big move coming!", "val": "!", "pos": None})

        if vol_signal in ["HIGH", "EXTREMELY_HIGH"]:
            if pct >= 0:
                score += 2; breakdown.append({"text": "HIGH VOLUME + Price UP = strong buying!", "val": "+2", "pos": True})
            else:
                score -= 2; breakdown.append({"text": "HIGH VOLUME + Price DOWN = strong selling!", "val": "-2", "pos": False})

        # Final recommendation
        if score >= 6:    rec = "VERY STRONG BUY"
        elif score >= 4:  rec = "STRONG BUY"
        elif score >= 2:  rec = "BUY"
        elif score >= 0:  rec = "HOLD"
        elif score >= -2: rec = "WEAK SELL"
        elif score >= -4: rec = "SELL"
        else:             rec = "STRONG SELL"

        # Chart data
        dates = [str(d)[:10] for d in close.index]
        prices_list = [sf(v) for v in close.values]
        vols   = [int(v) for v in volume.values]
        sma7s  = [sf(v) for v in close.rolling(7).mean().values]
        sma20s = [sf(v) for v in close.rolling(20).mean().values]

        return jsonify({
            "company":       company_name,
            "symbol":        symbol,
            "currency":      currency,
            "latest":        sf(latest),
            "change":        sf(change),
            "pct_change":    sf(pct),
            "avg_price":     sf(float(close.mean())),
            "highest":       sf(float(high.max())),
            "lowest":        sf(float(low.min())),
            "best_day":      sf(float(daily_ret.max())),
            "worst_day":     sf(float(daily_ret.min())),
            "avg_daily":     sf(avg_daily, 3),
            "sma7":          sma7,
            "sma20":         sma20,
            "rsi":           current_rsi,
            "rsi_signal":    rsi_signal,
            "macd":          curr_macd,
            "macd_signal_line": curr_sig,
            "macd_hist":     curr_hist,
            "macd_signal":   macd_signal,
            "bb_upper":      curr_upper,
            "bb_lower":      curr_lower,
            "bb_bandwidth":  curr_bw,
            "bb_avg_bw":     avg_bw,
            "bb_signal":     bb_signal,
            "bb_squeeze":    bb_squeeze,
            "avg_volume":    round(avg_vol),
            "latest_volume": round(latest_vol),
            "vol_ratio":     sf(vol_ratio),
            "vol_signal":    vol_signal,
            "unusual_days":  unusual,
            "score":         score,
            "recommendation": rec,
            "breakdown":     breakdown,
            "chart": {
                "dates":    dates,
                "prices":   prices_list,
                "volumes":  vols,
                "sma7":     sma7s,
                "sma20":    sma20s,
                "bb_upper": bb_upper_v,
                "bb_lower": bb_lower_v,
                "rsi":      rsi_vals,
                "macd":     macd_vals,
                "macd_sig": sig_vals,
                "macd_hist":hist_vals,
                "bb_bw":    bb_bw_v,
            }
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("=" * 50)
    print("  Stock Analyzer Web App is starting...")
    print("  Open your browser and go to:")
    print("  http://127.0.0.1:5000")
    print("  Press CTRL+C to stop")
    print("=" * 50)
    import os
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
